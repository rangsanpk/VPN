<?php

namespace App\Http\Controllers\API\ObjectStorage;

use App\Http\Controllers\API\Controller as BaseController;

class Controller extends BaseController
{
}
