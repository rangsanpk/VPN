<?php

namespace App\Services\Streamers;

interface DirectStreamerInterface extends StreamerInterface
{
}
