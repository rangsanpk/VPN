This is the official API documentation for [Koel](https://koel.phanan.net), generated from the source code using [Laravel API Documentation Generator](https://github.com/mpociot/laravel-apidoc-generator). 
If you spot any mistake or want to add an improvement, please [submit an issue](https://github.com/phanan/koel/issues/new) or [open a pull request](https://github.com/phanan/koel/compare).  
